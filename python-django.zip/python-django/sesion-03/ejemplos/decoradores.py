# Un decorador inerte que no modifica en nada
# a la función que envuelve

def decorador(func):
    def aux(*args, **kwargs):
        return func(*args, **kwargs)
    return aux

def llamar_dos_veces(func):
    def aux(*args, **kwargs):
        lista = []
        lista.append(func(*args, **kwargs))
        lista.append(func(*args, **kwargs))
        return lista
    return aux    

# Se puede aplicar con @ pero conceptualmente no está
# decorando sino sustiyendo una función por otra
def cambiar_por_suma(func):
    def suma(a, b):
        return a + b
    return suma

def suma(a, b):
    return a + b

@llamar_dos_veces
def suma_duplicada(a, b):
    return a + b

# Aplicar el decorador con "@" (osea "decorar la función") 
# es lo mismo que producir una nueva versión de la función
# a partir de su versión original y asignarla al mismo símbolo
# suma_duplicada = llamar_dos_veces(suma_duplicada)

@llamar_dos_veces
@llamar_dos_veces
def suma_cuadruplicada(a, b):
    return a + b
    
# suma_cuadruplicada = llamar_dos_veces(llamar_dos_veces(suma_cuadruplicada))

if __name__ == '__main__':
    suma2 = decorador(suma)
    print(suma2(1,1))
    
    suma3 = llamar_dos_veces(suma)
    print(suma3(1,1))
    
    print(suma_duplicada(2,2))
    
    print(suma_cuadruplicada(2,2))

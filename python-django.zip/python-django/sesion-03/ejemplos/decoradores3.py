def verificar_mayoria_edad(mayoria_edad):
    def decorador(func):
        def aux(edad, *args, **kwargs):
            if edad >= mayoria_edad:
                return func(edad, *args, **kwargs)
            else:
                print(f"ERROR: Ud. no cumple la mayoría de edad ({edad})")
        return aux
    return decorador
    

@verificar_mayoria_edad(21)
def votar(edad):
    print(f"Edad: {edad} - Estoy votando")
    
@verificar_mayoria_edad(18)
def ver_pelicula(edad):
    print(f"Edad: {edad} - Viendo película")
    
if __name__ == '__main__':

    votar(20)
    votar(23)
    
    ver_pelicula(8)
    ver_pelicula(40)


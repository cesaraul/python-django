IGV = 0.18

def suma(a, b):
    """
    Es función pura si el resultado depende solamente
    de los argumentos
    """
    return a + b
    
def calcular_igv(monto):
    """
    No es una función pura porque el resultado depende del
    argumento y de una variable global (que no es argumento)
    """
    return monto * IGV

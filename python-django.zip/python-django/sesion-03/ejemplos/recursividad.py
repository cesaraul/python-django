def factorial_no_recursivo(n):
    acum = 1 # Elemento neutro de la multiplicación
    for i in range(1, n+1):
        acum *= i # La variable "acum" está mutando
    return acum

def factorial_recursivo(n):
    if n > 0:
        return n * factorial_recursivo(n-1)
    elif n == 0:
        return 1    

if __name__ == '__main__':

    valor1 = factorial_no_recursivo(5)
    valor2 = factorial_recursivo(5)
    print(f"valor1: {valor1}")
    print(f"valor2: {valor2}")
    assert valor1 == valor2

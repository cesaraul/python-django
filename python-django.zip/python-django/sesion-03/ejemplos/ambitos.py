a = 10 # símbolo "a" en el ámbito global

def imprimir_a():
    print(a)
    
def imprimir_a_2():
    # localmente reasigno el símbola "a" a una nueva variable de ámbito local
    # CUIDADO: es otra variable, no tiene nada que ver con la otra.
    a = 30 
    print(a)

def imprimir_a_3():
    global a
    a = 40
    print(a)

if __name__ == '__main__':
    imprimir_a()
    
    a = 20
    
    imprimir_a()
    
    imprimir_a_2()
    
    imprimir_a()
    
    imprimir_a_3()
    
    imprimir_a()
    
    print(a)
    

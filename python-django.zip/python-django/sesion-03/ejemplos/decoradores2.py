MAYORIA_DE_EDAD = 18

def verificar_mayoria_edad(func):
    def aux(edad, *args, **kwargs):
        if edad >= MAYORIA_DE_EDAD:
            return func(edad, *args, **kwargs)
        else:
            print("ERROR: Ud. no cumple la mayoría de edad")
    return aux
    

@verificar_mayoria_edad
def votar(edad):
    print(f"Edad: {edad} - Estoy votando")
    
@verificar_mayoria_edad
def ver_pelicula(edad):
    print(f"Edad: {edad} - Viendo película")
    
if __name__ == '__main__':

    votar(17)
    votar(23)
    
    ver_pelicula(8)
    ver_pelicula(40)

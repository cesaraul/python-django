def crear_suma():
    # el símbolo "suma" es local, solo tiene sentido dentro de esta
    # llamada a función
    def suma(a, b):
        return a + b
    # con return devolvemos el valor (cómo si fuera una función anónima)
    # y el nombre que tenga dependerá de quien lo recibe.
    return suma
    
def crear_sumadora(n):
    # El símbolo "n" es un parámetro de la función en donde se define
    # la función sumadora y puede cambiar en cada llamada.
    def sumadora(x):
        return x + n
    return sumadora
    
if __name__ == '__main__':
    suma2 = crear_suma()
    print(suma2(1,1))
    
    sumadora_de_cincos = crear_sumadora(5)
    print(sumadora_de_cincos(100))

"""
Imprimir los cubos del 1 al 10
"""
from functools import reduce

cubos = []
for i in range(1, 10 + 1):
    cubos.append( i*i*i)
print(cubos)

def mapear(func, lista):
    nueva_lista = []
    for e in lista:
        nueva_lista.append( func(e) )
    return nueva_lista
    
def filtrar(func, lista):
    nueva_lista = []
    for e in lista:
        if func(e):
            nueva_lista.append(e)
    return nueva_lista
    
def reducir(func, lista, valor_inicial=0):
    resultado_parcial = valor_inicial
    for e in lista:
        resultado_parcial = func(resultado_parcial, e)
    return resultado_parcial
    
def elevar_al_cubo(x):
    return x*x*x
    
def es_par(x):
    return x % 2 == 0
    
def sumar(a, b):
    return a + b
    
cubos = mapear(elevar_al_cubo, range(1, 10+1))
print(cubos)

cubos = map(elevar_al_cubo, range(1, 10+1))
print(cubos)

cubos = map(lambda x: x**3, range(1, 10+1))
print(cubos)

cubos_pares = filtrar(es_par, cubos)
print(cubos_pares)

cubos_pares = filter(lambda x: x % 2 == 0, cubos)
print(cubos_pares)

suma_cubos_pares = reducir(sumar, cubos_pares)
print(suma_cubos_pares)

suma_cubos_pares = reduce(lambda a, b: a + b, cubos_pares)
print(suma_cubos_pares)

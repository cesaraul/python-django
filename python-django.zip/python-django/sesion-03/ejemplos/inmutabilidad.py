"""
Se dice que una variable "muta" cuando cambia de valor.

Las operaciones inmutables crean nuevos objetos, nunca asignan
una segunda vez un valor a un objeto que ya ha sido inicializado.
"""

# La lista 1 está mutando
lista1 = ["Hugo", "Paco", "Luis"]
lista1.append("Donald")

# Con inmutabilidad sería algo así:
lista2 = ["Hugo", "Paco", "Luis"]
lista3 = lista2.copy() + ["Donald"]

print(lista1)
print(lista3)
assert lista1 == lista3
print(id(lista1))
print(id(lista3))

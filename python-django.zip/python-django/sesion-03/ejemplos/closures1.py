"""
Una función que *encierra* una ó más referencias a símbolos que no son
locales ni parámetros. 
"""

IGV = 0.18

a = 10

def imprimir_a():
    """
    Esta funcíon SI es un closure porque encierra una referencia
    a la variable no local "a"
    """
    print(a)
    
def imprimir_a_2():
    """
    Esta función NO es un closure porque "a" es una variable local.
    """
    a = 30 
    print(a)
    
sumar_a = lambda x: x + a # Es closure porque encierra una referencia a "a"

otra = lambda x: x+1 # No es closure, solo referencia a sus parámetros

# No es closure, solo utiliza sus parámetros 
def suma(a, b):
    return a + b

# Si es closure, referencia a IGV que no es ni parámetro ni variable local
def calcular_igv(monto):
    return monto * IGV
 
    


"""
Implementar una función recursiva que invierta los
elementos de una cadena ó lista teniendo en cuenta:

* Si la secuencia está vacía, su inversa es ella misma
* Toda secuencia puede ser invertida concatenado el inverso
  el inverso de la cola y la cabeza.
  
Ejemplo:

[1, 2, 3] == [3, 2] + [1] == [3, 2, 1]
"Hola" == "alo" + "H" == "aloH"
"H" == '' + "H" == "H"
[] == [] + []  == []

Cabeza: secuencia[:1]
Cola: secuencia[1:]
"""

def invertir_secuencia(secuencia):

    if len(secuencia) == 0:
        return secuencia
    else:
        return invertir_secuencia(secuencia[1:]) + secuencia[:1]
        
if __name__ == '__main__':

    assert invertir_secuencia("Hola") == "aloH"
    assert invertir_secuencia([1, 2, 3]) == [3, 2, 1]
    assert invertir_secuencia("H") == "H"
    assert invertir_secuencia([]) == []
    assert invertir_secuencia("") == "" 

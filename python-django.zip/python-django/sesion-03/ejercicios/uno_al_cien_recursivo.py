"""
Imprimir los números del 1 al 100 sin utilizar bucles como while ó for,
sino en su lugar, empleando recursividad.
"""

INICIO = 1
FIN = 100

def imprimir(n=None):
    if not n:
        n = 1
    print(n)
    if n < FIN:
        imprimir(n+1)
        
def imprimir2(i, valor_maximo):
    print(i)
    if i < valor_maximo:
        imprimir2(i+1, valor_maximo)

if __name__ == '__main__':
    imprimir()
    imprimir2(INICIO, FIN)

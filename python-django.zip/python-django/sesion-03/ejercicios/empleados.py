"""
Generar aleatoriamente datos de 100 empleados considerando
los siguientes campos:

* genero: que es un valor entre "M" ó "F"
* sueldo: que es un valor entre 1500 y 9500 soles (en intervalos de 100)
* contratacion: que es una fecha entre 2000 y 3000 dias en el pasado

Representar cada empleado como un diccionario.

Ejemplo:

{'genero': 'M', 'sueldo': 5500, 'contratacion': date(2012, 12, 28)}

Debe generar una lista con 100 diccionarios de ese tipo.

Recuerde que para obtener la fecha actual se hace lo siguiente:

fecha_hoy = datetime.date.today()

Para calcular una fecha en el pasado:

fecha_anterior = fecha_hoy - datetime.timedelta(days=1234)

"""

import datetime
import operator
from functools import reduce
from random import (
    randint,
    choice
 )
 
NUM_EMPLEADOS = 100
 
GENERO_MASCULINO = 'M'
GENERO_FEMENINO = 'F'

RANGO_SUELDO_INICIO = 1500
RANGO_SUELDO_FIN = 9500
RANGO_SUELDO_SALTO = 100

ANTIGUEDAD_MAXIMA = 3000
ANTIGUEDAD_MINIMA = 2000

OPCIONES_GENERO = (GENERO_MASCULINO, GENERO_FEMENINO)

empleados = []

while len(empleados) < NUM_EMPLEADOS:

    emp = {}
    emp['genero'] = choice(OPCIONES_GENERO)
    emp['sueldo'] = randint(
        int(RANGO_SUELDO_INICIO/RANGO_SUELDO_SALTO),
        int(RANGO_SUELDO_FIN/RANGO_SUELDO_SALTO)
    ) *  RANGO_SUELDO_SALTO
    emp['contratacion'] = datetime.date.today() - datetime.timedelta(
        days=randint(ANTIGUEDAD_MINIMA, ANTIGUEDAD_MAXIMA)
    )

    empleados.append(emp)


filtrados = filter(lambda e: e['genero'] == 'F', empleados)
filtrados = filter(
    lambda e: (datetime.date.today() - e['contratacion']).days <= 2500,
    filtrados
)
sueldos = list(map(lambda e: e['sueldo'], filtrados))
#print(sueldos)
numerador = reduce(operator.add, sueldos, 0)
#print(numerador)
denominador = reduce(operator.add, map(lambda x: 1, sueldos), 0)

try:
    promedio = numerador / denominador
except ZeroDivisionError:
    promedio = 0.0
    
print(f"Promedio de sueldos: S/. {promedio:.2f}")


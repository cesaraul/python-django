def suma(a, b):
    return a + b
    
print(suma(1, 1))
print(suma(2, 2))
print(suma("Hola", " mundo"))
print(suma(["Hugo", "Paco"], ["Luis"]))


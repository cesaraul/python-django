def suma(a, b, *por_posicion, **por_nombre): # *args, **kwargs
    print("por_posicion: ", por_posicion)
    print("por_nombre: ", por_nombre)
    return a + b + sum(por_posicion) + sum(por_nombre.values())
    
def funcion_sin_parametros_esperados(*args, **kwargs):
    print("por_posicion: ", args)
    if not args:
        print("No hay argumentos por posición")
    print("por_nombre: ", kwargs)
    if not kwargs:
        print("No hay argumentos por nombre")
    
print(suma(1, 1))
print(suma(1, 1, 1))
print(suma(1, 1, 1, 1, x=1, y=1))

funcion_sin_parametros_esperados(1, 2, 3, x=4, y=5)
funcion_sin_parametros_esperados(1, 2, 3, x=4, y=5)

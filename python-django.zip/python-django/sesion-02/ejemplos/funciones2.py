def subrayar(cadena, caracter='*', nl=False):
    print(cadena)
    print(caracter * len(cadena))
    if nl:
        print()

if __name__ == '__main__':
    subrayar("Hola mundo")
    subrayar("Hola mundo", "=")
    subrayar("Hola mundo", "-", True)
    subrayar("Hola mundo", nl=True)
    subrayar(caracter=".", nl=False, cadena="Hola mundo")

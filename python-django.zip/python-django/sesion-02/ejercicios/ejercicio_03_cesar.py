from random import (randint,sample)

B_INICIAL = 1
B_FINAL = 45

NUM_BOLILLAS_POR_JUGADA = 6

NUM_JUGADAS_DISTINTAS=100

jugadas=[] 

for i in range(1,100+1):
   
    while True:
        jugada='-'.join(["%02d" % b for b in sorted(sample(range(B_INICIAL,B_FINAL+1),NUM_BOLILLAS_POR_JUGADA))])
        if jugada not in jugadas:
            break
    jugadas.append(jugada)
jugadas.sort()
print(jugadas)
print(len(JUGADAS))

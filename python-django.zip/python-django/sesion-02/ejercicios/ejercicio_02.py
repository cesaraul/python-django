"""
Generar números aleatorios entre 1 y 100 de forma que
se llenen dos listas de 5 elementos, primero una de números 
pares y luego, cuando esta ya esté completa, otra de números
impares.

Imprimir ambas listas al final del programa.

Consideraciones adicionales:

* Los números en cada lista SI pueden repetirse
* Los números en cada lista NO tienen porque estar en orden
"""

from time import sleep
from random import randint

INICIO_RANGO = 1
FIN_RANGO = 100
NUM_POR_LISTA = 5
PAUSA = 1

# ¿que estamos buscando?
buscando = 'pares'

lista_pares = []
lista_impares = []

while (len(lista_pares) < NUM_POR_LISTA) or (len(lista_impares) < NUM_POR_LISTA):
    print(f"buscando: {buscando}") 
    print("Pares: ", lista_pares)
    print("Impares: ", lista_impares)
    numero = randint(INICIO_RANGO, FIN_RANGO)
    print("numero: %d" % numero)
    if buscando == 'pares' and (numero % 2 == 0):
        lista_pares.append(numero)
        if len(lista_pares) == NUM_POR_LISTA:
            buscando = 'impares'
    elif buscando == 'impares' and (numero % 2 != 0):
        lista_impares.append(numero)
    sleep(PAUSA)

print("Pares: ", lista_pares)
print("Impares: ", lista_impares)


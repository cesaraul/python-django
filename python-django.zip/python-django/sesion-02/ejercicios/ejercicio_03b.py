"""
Generar 100 jugadas distintas de la Tinka considerando que:
1. Cada jugada de la Tinka incluye 06 bolillas entre los valores
   1 a 45 que NO se repiten
2. Que cada jugada debe ser representada como una cadena de números
   con cero a la izquierda para que tengan longitud 2 y unidos por
   guiones. Ej. 03-09-11-23-35-40
3. La lista de jugadas distintas deben presentarse ordenada
"""

from random import randint

BOLILLA_INICIAL = 1
BOLILLA_FINAL = 45

NUM_BOLILLAS_POR_JUGADA = 6

NUM_JUGADAS_DISTINTAS = 100

jugadas = []

while len(jugadas) < NUM_JUGADAS_DISTINTAS:

    jugada = []
    while(len(jugada) < NUM_BOLILLAS_POR_JUGADA):
        bolilla = randint(BOLILLA_INICIAL, BOLILLA_FINAL+1)
        if bolilla not in jugada:
            jugada.append(bolilla)
    
    jugada.sort()
    lista_auxiliar = []
    for b in jugada:
        lista_auxiliar.append("%02d" % b)
    jugada_como_cadena = "-".join(lista_auxiliar)
    
    if jugada_como_cadena not in jugadas:
        jugadas.append(jugada_como_cadena)

jugadas.sort()

for j in jugadas:
    print(j)

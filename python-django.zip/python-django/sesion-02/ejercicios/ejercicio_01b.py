"""
Escribir un programa que obtenga un número entero 
aleatorio entre 100 y 300 e imprima tantas líneas
como indique dicho número pero imprimiendo una 
secuencia de un solo asterísco por línea, luego
dos asteriscos y luego tres, volviendo a imprimir
uno solo en la línea siguiente.

Por ejemplo, si el número fuera 5, la salida sería así:
*
**
***
*
**

Y si el número fuera 7, la salida sería así:

*
**
***
*
**
***
*
"""

from random import randint

INICIO_RANGO = 1 #100
FIN_RANGO = 10 #300
MAX_ASTERISCOS = 3

num_lineas = randint(INICIO_RANGO, FIN_RANGO)
print(num_lineas)

for i in range(num_lineas):
    asteriscos = (i % MAX_ASTERISCOS) + 1
    print("{i}: {asteriscos}".format(i=i+1, asteriscos=('*' * asteriscos)))


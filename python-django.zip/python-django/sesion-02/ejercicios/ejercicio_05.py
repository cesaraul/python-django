"""
Escribir una función que genere una sentencia SQL

select("empleados", ['cod_empleado', 'email', 'cod_jefe'], sueldo__gte=5000)

"SELECT cod_empleado, email, cod_jefe FROM empleados WHERE sueldo >= 5000"

select("empleados")

"SELECT * FROM empleados"
"""

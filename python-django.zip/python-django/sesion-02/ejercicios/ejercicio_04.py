"""
Escribir un programa en Python que genere 100 licencias estilo "Windows"
distintas, considerando que:

* Cada licencia está formada por 5 grupos de 5 caracteres separados por "-"
* Que cada caracter puede repetirse dentro de un grupo
* Que los caracteres válidos son los dígitos decimales (0 al 9) y las letras
  del alfabeto ingleś (A a la Z sin Ñ)
  
Ejemplo de una licencia:

AB788-HQP31-PPQ7B-YHHM8-JHKI9

Dividir el problema en varias funciones:

def generar_licencias_distintas(num_licencias=100):
    pass
    
def generar_licencia(num_grupos=5, separador="-"):
    pass
    
def generar_grupo(num_caracteres=5, alfabeto="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ")    
    pass
    
Imprimir las licencias generadas en forma ordenada con el siguiente formato:

001.- AB788-HQP31-PPQ7B-YHHM8-JHKI9
...
099.- Z9KJK-UYGJX-HGRUY-75KHF-GHFEP
100.- ZZTY9-986KH-VBNMP-76KNB-HOIM4
"""
from random import choice

def generar_grupo(num_caracteres=5, alfabeto="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
    # return ''.join([choice(alfabeto) for x in range(num_caracteres)])   
    caracteres = []
    for x in range(num_caracteres):
        caracteres.append(choice(alfabeto))
    return ''.join(caracteres)
    
def generar_licencia(num_grupos=5, separador="-"):
    # return separador.join([generar_grupo() for x in range(num_grupos)])
    grupos = []
    for x in range(num_grupos):
        grupos.append( generar_grupo() )
    return separador.join(grupos)
    
def generar_licencias_distintas(num_licencias=100, ordenar=True):
    licencias = []
    while(len(licencias) < num_licencias):
        l = generar_licencia()
        if l not in licencias:
            licencias.append(l)
    if ordenar:
        licencias.sort()
    return licencias
    
#print(generar_grupo())
#print(generar_licencia())

licencias = generar_licencias_distintas()

#i = 1
#for l in licencias:
#    print("%03d.- %s" % (i, l))
#    i += 1

for nro, licencia in enumerate(licencias, 1):
    print(f"{nro:03d}.- {licencia}")

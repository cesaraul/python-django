from time import sleep

PAUSA = 0.25

i = 1

while True:
    print(i)
    i += 1
    sleep(PAUSA)

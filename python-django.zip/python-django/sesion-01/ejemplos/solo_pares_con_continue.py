i = 0

while i <= 10:
    i += 1
    if i % 2 != 0:
         continue # Regresa a la condición y se saltea el resto del cuerpo
    print(i)

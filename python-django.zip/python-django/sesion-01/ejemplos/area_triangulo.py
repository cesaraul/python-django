base = 13.5
altura = 12.3

area = (base * altura) / 2

print("Area del triángulo")
print("******************")
print()
print(f"Base: {base:.2f}")
print(f"Altura: {altura:.2f}")
print(f"Área: {area:.2f}")

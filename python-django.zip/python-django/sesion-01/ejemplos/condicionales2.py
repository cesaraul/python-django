mes = 200

if (mes == 4) or (mes == 6) or (mes == 9) or (mes == 11):
    print("El mes tiene 30 días")
elif  (mes == 1) or (mes == 3) or (mes == 5) or \
    (mes == 7) or (mes == 8) or (mes == 10) or (mes == 12):
    print("El mes tiene 31 días")
elif (mes == 2):
    print("El mes tiene 28 ó 29 dias")
else:
    print("El valor está fuera de rango")


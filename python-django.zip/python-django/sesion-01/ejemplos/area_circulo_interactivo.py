from math import pi

while True:
    try:
        radio = float(input("Ingrese el radio: "))
        break
    except ValueError:
        print("ERROR: El valor ingresado debe ser un número")
    
area = pi * (radio ** 2)

print("Área del círculo")
print("****************")
print()
print(f"Radio: {radio:.2f}")
print(f"Área: {area:.2f}")

# Ejecuta el cuerpo del while 100 veces
i = 1
while i <= 100:
    print(i)
    i += 1

# Ejecuta el cuerpo del while 100 veces
i = 0
while i < 100:
    print(i)
    i += 1

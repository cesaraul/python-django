MAYORIA_DE_EDAD = 18

edad = 17

if edad >= MAYORIA_DE_EDAD:
    print("Ud. es mayor de edad")
else:
    print("Ud. es menor de edad")

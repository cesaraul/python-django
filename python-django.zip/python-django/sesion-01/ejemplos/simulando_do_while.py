"""
En lenguajes como C, C++, Java, C#, PHP, Javacript existe
la sentencia do-while que primero ejecuta el cuerpo del bucle
y luego evalua la condición para ver si se ejecuta el cuerpo
una vez más.

Ejemplo en Javascript:

var i = 1;
do {
    console.log(i);
} while (i <= 10);

1
.
.
.
10
"""

i = 1
while True:
    print(i)
    i += 1
    if not (i <= 10):
        break

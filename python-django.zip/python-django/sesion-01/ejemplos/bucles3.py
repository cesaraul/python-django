i = 0
while i <= 100:
    print(i)
    i += 5

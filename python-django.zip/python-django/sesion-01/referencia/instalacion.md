# Instalación de Python

## En Ubuntu 18.04

```
sudo apt install build-essential python3 python3-setuptools python3-pip virtualenv virtualenvwrapper python3-dev
```



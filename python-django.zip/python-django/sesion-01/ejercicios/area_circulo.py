from math import pi

radio = 50
area = pi * (radio ** 2)

print("Área del círculo")
print("****************")
print()
print(f"Radio: {radio:.2f}")
print(f"Área: {area:.2f}")

"""
Implementar un programa en Python que determine si un año 
es o no bisiesto considerando las siguentes reglas:

- Es bisiesto si es múltiple de 4 pero no es multiplo de 100
- Es bisiesto si es múltiple de 400

Debe cumplir una de estas dos reglas.
"""

anio = 2020

if ((anio % 4 == 0) and not (anio % 100 == 0)) or (anio % 400 == 0):
    print(f"El año {anio} si es bisiesto")
else:
    print(f"El año {anio} no es bisiesto")

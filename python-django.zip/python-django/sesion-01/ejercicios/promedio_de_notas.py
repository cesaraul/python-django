NOTA_MINIMA = 0.0
NOTA_MAXIMA = 20.0

MARCADOR_FIN = -1

contador = 0
acumulador = 0

while True:

    # Leyendo una nota
    while True:
        try:
            nota = float(input("Ingrese una nota: "))
            if nota == MARCADOR_FIN:
                break
            if (nota < NOTA_MINIMA) or (nota > NOTA_MAXIMA):
                print(
                    "ERROR: La nota debe estar entre {min} y {max}".format(
                        min=NOTA_MINIMA,
                        max=NOTA_MAXIMA
                     )
                )
                continue
            break
        except ValueError:
            print("ERROR: El valor ingresado debe ser un número")            
        

    if nota == MARCADOR_FIN:
        break
     
    contador += 1
    acumulador += nota

# promedio = 0.0
# if contador > 0:
#    promedio = acumulador / contador

try:
    promedio = acumulador / contador
except ZeroDivisionError:
    promedio = 0.0

print(f"Cantidad de notas ingresadas: {contador}")
print(f"Promedio de notas: {promedio:.2f}")

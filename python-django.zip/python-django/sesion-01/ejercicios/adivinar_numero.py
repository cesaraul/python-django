from random import randint

INICIO_RANGO = 1
FIN_RANGO = 100

aleatorio = randint(INICIO_RANGO, FIN_RANGO)

while True:

    # Leyendo el número 
    while True:
        try:
            numero = int(input("Ingrese un numero: "))
            break
        except ValueError:
            print("ERROR: El valor ingresado debe ser un número")
    
    if aleatorio > numero:
        print("AYUDA: El número aleatorio generado es mayor que el ingresado")
    elif aleatorio < numero:
        print("AYUDA: El número aleatorio generado es menor que el ingresado")
    elif aleatorio == numero:
        print(f"¡Adivinó! El número aleatorio generado era {aleatorio}")
        break


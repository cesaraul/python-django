from random import randint

INICIO_RANGO = 1
FIN_RANGO = 100
MAX_INTENTOS = 5

aleatorio = randint(INICIO_RANGO, FIN_RANGO)
intentos = 0

while True:

    if intentos > MAX_INTENTOS:
        print(f"¡Ud perdió! Ha superado el número máximo de {MAX_INTENTOS} intentos")
        break

    # Leyendo el número 
    while True:
        try:
            numero = int(input("Ingrese un numero: "))
            intentos += 1
            break
        except ValueError:
            print("ERROR: El valor ingresado debe ser un número")
   
    if aleatorio > numero:
        print("AYUDA: El número aleatorio generado es mayor que el ingresado")
    elif aleatorio < numero:
        print("AYUDA: El número aleatorio generado es menor que el ingresado")
    elif aleatorio == numero:
        print(f"¡Adivinó en {intentos} intento(s)! El número aleatorio generado era {aleatorio}")
        break


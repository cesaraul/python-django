import datetime

IGV = 0.18

class Empresa(object):

    def __init__(self, razon_social, ruc, direccion):
        self.razon_social = razon_social
        self.ruc = ruc
        self.direccion = direccion
        self.series = []
    
    def __str__(self):
        return self.razon_social
    
    def obtener_serie_vigente(self):
        try:
            return self.series[-1]
        except IndexError:
            pass
        
 
class Producto(object):
 
    def __init__(self, nombre, precio_unitario):
        self.nombre = nombre
        self.precio_unitario = precio_unitario
        
 
class Serie(object):
 
    def __init__(self, imprenta, numero, inicio, fin, fecha, autorizacion):
        self.imprenta = imprenta
        self.numero = numero
        self.inicio = inicio
        self.fin = fin
        self.actual = self.inicio
        self.fecha = fecha
        self.autorizacion = autorizacion
        
    def siguiente_numero(self):
        aux = self.actual
        self.actual += 1
        return aux
        
class DetalleFactura(object):
 
    def __init__(self, producto, cantidad):
        self.producto = producto
        self.cantidad = cantidad
        
    def calcular_valor_de_venta(self):
        return self.producto.precio_unitario * self.cantidad
        
 
class Factura(object):
 
    def __init__(self, emisor, receptor, fecha=None):
        self.emisor = emisor
        self.receptor = receptor
        self.serie = emisor.obtener_serie_vigente()
        if fecha is None:
            self.fecha = datetime.date.today()
        self.numero = self.serie.siguiente_numero()
        self.detalles = []
        
    def agregar_detalle(self, producto, cantidad):
        detalle = DetalleFactura(producto, cantidad)
        self.detalles.append(detalle)
        
    def calcular_subtotal(self):
        acumulador = 0.0
        for detalle in self.detalles:
            acumulador += detalle.calcular_valor_de_venta()
        return acumulador
        
    def calcular_igv(self, subtotal=None):
        if subtotal is None:
            subtotal = self.calcular_subtotal()
        return subtotal * IGV
        
    def calcular_total(self, subtotal=None, impuesto=None):
        if subtotal is None:
            subtotal = self.calcular_subtotal()
        if impuesto is None:
            impuesto = self.calcular_igv(subtotal)
        return subtotal + impuesto
    
    def __iter__(self):
        return iter(self.detalles)
        
if __name__ == '__main__':

    # Creamos el inventario de productos
    producto1 = Producto("Tarro de leche Gloria", 4.00)
    producto2 = Producto("Bolsa de chancays de 12 unidades", 3.00)
    producto3 = Producto("Sublime clásico", 1.50)
    
    # Creamos a la empresa emisora
    empresa1 = Empresa(
        razon_social="Bodeguita de Don Maria S.A.C.",
        ruc="10102030405",
        direccion="Av. Arequipa 1540, Lince"
    )
    
    # Creamos la empresa receptora
    empresa2 = Empresa(
        razon_social="Grupo Adiestra S.A.C.",
        ruc="10203040503",
        direccion="Calle Emilio de Althaus 129 of. 501, Lince"
    )
    
    # Creamos a la imprenta
    empresa3 = Empresa(
        razon_social="Imprenta Canevaro E.I.R.L",
        ruc="20123456784",
        direccion="Av. Canevaro 123, Lince"
    )
    
    # Serie
    serie1 = Serie(
        imprenta=empresa3,
        numero=1,
        inicio=1,
        fin=1000,
        fecha=datetime.date(2013, 8, 17),
        autorizacion="0123456789"
    )
    
    # Agregamos al serie a la empresa emisora
    empresa1.series.append(serie1)
    
    # Creamos la factura
    factura = Factura(emisor=empresa1, receptor=empresa2)
    factura.agregar_detalle(producto1, 10)
    factura.agregar_detalle(producto2, 5)
    factura.agregar_detalle(producto3, 20)
    
    subtotal = factura.calcular_subtotal()
    impuesto = factura.calcular_igv(subtotal)
    total = factura.calcular_total(subtotal, impuesto)
    print(subtotal, impuesto, total)

class Triangulo(object):

    def __init__(self, base, altura):
        self.base = base
        self.altura = altura
    
    def calcular_area(self):
        resultado = (self.base * self.altura) / 2
        return resultado
        
       
if __name__ == '__main__':

    triangulo1 = Triangulo(100, 50)
    print("Base: {:.2f}".format(triangulo1.base))
    print("Altura: {:.2f}".format(triangulo1.altura))
    print("Área: {:.2f}".format(triangulo1.calcular_area()))

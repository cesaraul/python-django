"""
Dada la siguiente lista de empleados construir una cadena
con la siguiente forma solo para los empleados varones:

Pérez P., Juan
Choy P., Kim

Debe utilizar listas por comprensión

"""

empleados = [
    {
        "nombres": "Juan Alberto",
        "apepat": "Pérez",
        "apemat": "Palacios",
        "genero": "M"
    },
    {
        "nombres": "María del Rosario",
        "apepat": "García",
        "apemat": "Robles",
        "genero": "F"
    },
    {
        "nombres": "Kim",
        "apepat": "Choy",
        "apemat": "Park",
        "genero": "M"
    }   
]

print("\n".join(
    ["%s %s.,%s" % (e["apepat"], e["apemat"][0], e["nombres"].split(" ")[0])  for e in empleados if e['genero'] == 'M']
   )
)


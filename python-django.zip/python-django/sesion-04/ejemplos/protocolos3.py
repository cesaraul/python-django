class Sobrinos(object):

    def __init__(self):
        self.actual = None
        
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.actual is None:
            self.actual = 'Hugo'
        elif self.actual == 'Hugo':
            self.actual = 'Paco'
        elif self.actual == 'Paco':
            self.actual = 'Luis'
        elif self.actual == 'Luis':
            raise StopIteration
        return self.actual
 
def mi_propio_iter(objeto):
    return objeto.__iter__()
    
def mi_propio_next(objeto):
    return objeto.__next__()
 
def mi_propio_list(objeto):
    lista = []
    iterador = mi_propio_iter(objeto)
    while True:
        try:
            lista.append(mi_propio_next(iterador))
        except StopIteration:
            break
    return lista
    

if __name__ == '__main__':

    s = Sobrinos()
    print(mi_propio_list(s))   
        

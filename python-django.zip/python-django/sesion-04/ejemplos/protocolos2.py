class ListaFalsa(object):

    def __len__(self):
        return 1000
        
    def __getitem__(self, key):
        return 10
        
    def __getattr__(self, name):
        return "Hola"
        
if __name__ == '__main__':

    lista = ListaFalsa()
    print(len(lista))

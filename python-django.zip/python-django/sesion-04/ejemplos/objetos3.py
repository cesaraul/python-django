class Persona(object):


    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
    
    def saludar(self):
        print(f"Hola me llamo {self.nombre} y tengo {self.edad} años")
        

if __name__ == '__main__':

    # Creamos una instancia de la clase Persona, el objeto "persona1"
    persona1 = Persona(nombre="Juan", edad=10)
    persona1.saludar()
    
    # Creamos otra instancia de la clase Persona, el objeto "persona2"
    persona2 = Persona(nombre="María", edad=20)
    persona2.saludar()
    
    # Agregamos dinámicamente el atributo amigos
    persona2.amigos = []
    
    # Agregamos a la persona1 en la lista de amigos de la persona 2
    persona2.amigos.append(persona1)
    
    # Agregamos el atributo mejor_amigo a la instancia persona2
    persona2.mejor_amigo = persona1

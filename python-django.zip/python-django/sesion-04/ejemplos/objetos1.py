class Persona(object):

    nombre = "Juan"
    edad = 10
    
    def saludar(self):
        print(f"Hola me llamo {self.nombre} y tengo {self.edad} años")
        

if __name__ == '__main__':

    persona1 = Persona()
    persona1.saludar()

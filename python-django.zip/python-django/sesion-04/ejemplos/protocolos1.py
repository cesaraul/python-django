class Persona(object):


    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad
    
    def saludar(self):
        print(f"Hola me llamo {self.nombre} y tengo {self.edad} años")
        
    def __str__(self):
        return self.nombre
        
    def __repr__(self):
        template  = "<{clsname} nombre=\"{nombre}\" edad=\"{edad}\" "
        template += "at 0x{hexid:x}>"
        return template.format(
            clsname=self.__class__.__name__,
            nombre=self.nombre,
            edad=self.edad,
            hexid=id(self)
        )

if __name__ == '__main__':

    persona1 = Persona(nombre="Juan", edad=10)
    persona1.saludar()
    
    persona2 = Persona(nombre="María", edad=20)
    persona2.saludar()

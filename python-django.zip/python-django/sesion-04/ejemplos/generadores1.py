def mi_propio_range_con_generadores(inicio, fin, incremento):
    i = inicio
    while i < fin:
        yield i
        i += incremento
        
if __name__ == '__main__':
    
    obj = mi_propio_range_con_generadores(1, 100+1, 10)
    

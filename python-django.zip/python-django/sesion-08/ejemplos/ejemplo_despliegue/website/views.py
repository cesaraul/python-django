from django.shortcuts import render
from django.utils.timezone import localtime

# Create your views here.

def index(request):
    ts = localtime()
    return render(request, 'website/index.html', locals())
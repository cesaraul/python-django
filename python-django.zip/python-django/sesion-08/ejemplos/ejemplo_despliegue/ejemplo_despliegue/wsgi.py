"""
WSGI config for ejemplo_despliegue project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/2.2/howto/deployment/wsgi/
"""

import os
import sys

activator = '/var/vhosts/ejemplo-despliegue.pe/code/env/bin/activate_this.py'

with open(activator) as f:
    exec(f.read(), {'__file__': activator})

from django.core.wsgi import get_wsgi_application

sys.path.append(
'/var/vhosts/ejemplo-despliegue.pe/code'
)


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ejemplo_despliegue.settings')

application = get_wsgi_application()

from django.conf import settings
from django.shortcuts import render

# Create your views here.

def contador(request):
    if not 'contador' in request.session:
        request.session['contador'] = 0
    request.session['contador'] += 1
    contador = request.session.get('contador', None)
    session_key = request.session.session_key
    cookie_name = settings.SESSION_COOKIE_NAME
    return render(request, 'website/contador.html', locals())

def limpiar(request):
    request.session.flush()
    session_key = request.session.session_key
    return render(request, 'website/flush.html', locals())

def variables(request):
    items = request.session.items()
    session_key = request.session.session_key
    return render(request, 'website/variables.html', locals())
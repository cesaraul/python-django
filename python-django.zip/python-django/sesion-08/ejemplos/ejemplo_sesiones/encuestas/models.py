from django.db import models
from django.utils.translation import ugettext_lazy as _

# Create your models here.

class Encuesta(models.Model):

    titulo = models.CharField(
        verbose_name=_('Título'),
        max_length=128
    )

    class Meta:
        verbose_name = _('encuesta')
        verbose_name_plural = _('encuestas')

    def get_choices(self):
        choices = []
        for opcion in self.opciones.all():
            entry = (
                opcion.pk,
                opcion.valor
            )
            choices.append(entry)
        return choices

    def contar_votos(self):
        #contador = 0
        #for opcion in self.opciones.all():
        #    contador += opcion.contador
        #return contador
        resultados = self.opciones.all().aggregate(
            conteo_votos=models.Sum('contador')
        )
        return resultados['conteo_votos']

class Opcion(models.Model):

    encuesta = models.ForeignKey(Encuesta,
        verbose_name=_('Encuesta'),
        on_delete=models.PROTECT,
        related_name='opciones'
    )

    valor = models.CharField(
        verbose_name=('Texto de opción'),
        max_length=128
    )

    contador = models.PositiveIntegerField(
        verbose_name=_('Conteo de votos'),
        default=0
    )

    creado_en = models.DateTimeField(
        verbose_name=_('Fecha y hora de creación'),
        auto_now_add=True
    )

    actualizado_en = models.DateTimeField(
        verbose_name=_('Fecha y hora de creación'),
        auto_now=True
    )

    class Meta:
        verbose_name = _('opción')
        verbose_name_plural = _('opciones')
from django import forms
from .models import Opcion

class EncuestaForm(forms.Form):

    def __init__(self, encuesta, *args, **kwargs):
        self.encuesta = encuesta
        super().__init__(*args, **kwargs)
        self.fields["question"] = forms.ChoiceField(
            label=self.encuesta.titulo, 
			widget=forms.RadioSelect(), 
			choices = self.encuesta.get_choices()
        )

    def save(self, *args, **kwargs):
        opcion_pk = self.cleaned_data['question']
        try:
            opcion = Opcion.objects.get(
                pk=opcion_pk
            )
            opcion.contador += 1
            opcion.save()
        except Opcion.DoesNotExist:
            return None


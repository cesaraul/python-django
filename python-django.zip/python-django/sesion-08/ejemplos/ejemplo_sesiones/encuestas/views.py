from django.shortcuts import (
    render,
    get_object_or_404
)
from .models import Encuesta
from .forms import EncuestaForm

# Create your views here.

def listado(request):
    encuestas = Encuesta.objects.all()
    return render(request, 'encuestas/listado.html', locals())

def formulario(request, encuesta_pk):
    ya_ha_votado = encuesta_pk in request.session.get('encuestas', [])
    encuesta = get_object_or_404(Encuesta, pk=encuesta_pk)
    mostrar_resultados = ya_ha_votado
    if request.method == 'POST' and not ya_ha_votado:
        form = EncuestaForm(
            encuesta=encuesta,
            data=request.POST
        )
        if form.is_valid():
            form.save()
            mostrar_resultados = True
            if 'encuestas' not in request.session:
                request.session['encuestas'] = []    
            request.session['encuestas'].append(encuesta_pk)
            request.session.save()
    else:
        form = EncuestaForm(encuesta=encuesta)
    return render(request, 'encuestas/formulario.html', locals())
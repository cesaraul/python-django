from django.contrib import admin
from django.utils.translation import ugettext_lazy as _
from .models import (
    Encuesta,
    Opcion
)

# Register your models here.

class OpcionAdmin(admin.TabularInline):
    model = Opcion

class EncuestaAdmin(admin.ModelAdmin):

    list_display = (
        'id', 'titulo', 
        'conteo_opciones', 
        'conteo_votos'
    )

    inlines = [OpcionAdmin]

    def conteo_opciones(self, instance):
        return instance.opciones.count()
    conteo_opciones.short_descripcion = _('Conteo de opciones')

    def conteo_votos(self, instance):
        return instance.contar_votos()
    conteo_votos.short_description = _('Conteo de votos')

admin.site.register(Encuesta, EncuestaAdmin)
from django.apps import AppConfig


class EncuestasConfig(AppConfig):
    name = 'encuestas'

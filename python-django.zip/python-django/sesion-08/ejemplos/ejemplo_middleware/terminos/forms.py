from django import forms
from django.utils.translation import ugettext_lazy as _

class TerminosForm(forms.Form):

    acepta_terminos = forms.BooleanField(
        label=_('¿Acepta los términos y condiciones?')
    )
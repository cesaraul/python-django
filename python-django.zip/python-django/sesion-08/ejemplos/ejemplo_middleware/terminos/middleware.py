from django.conf import settings
from django.http import HttpResponseRedirect
from django.urls import reverse

def aceptacion_terminos(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.
        
        terms_url = reverse(settings.TERMINOS_VIEW_NAME)
        pagina_terminos = request.path == terms_url
        aceptacion_terminos = request.COOKIES.get(
            settings.TERMINOS_COOKIE_NAME,
            '0'
        )
        if not pagina_terminos and aceptacion_terminos != '1':
            request.session['next'] = request.path_info
            request.session.save()
            response = HttpResponseRedirect(terms_url)
        else:
            response = get_response(request)

        # Code to be executed for each request/response after
        # the view is called.

        return response

    return middleware

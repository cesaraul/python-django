from django.conf import settings
from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import TerminosForm

# Create your views here.
def aceptacion_terminos(request):
    aceptacion_terminos = request.COOKIES.get(
        settings.TERMINOS_COOKIE_NAME,
        '0'
    )
    if aceptacion_terminos == '1':
        terminos_aceptados = True
    if request.method == 'POST':
        form = TerminosForm(request.POST)
        if form.is_valid():
            url = request.session.pop('next', '/')
            response = HttpResponseRedirect(url)
            response.set_cookie(
                settings.TERMINOS_COOKIE_NAME,
                settings.TERMINOS_COOKIE_VALUE,
                settings.TERMINOS_COOKIE_MAX_AGE
            )
            return response
    else:
        form = TerminosForm()
    return render(request, settings.TERMINOS_TEMPLATE, locals())

def borrar_cookie_terminos(request):
    response = render(request, 'website/borrar_terminos.html')
    response.delete_cookie(settings.TERMINOS_COOKIE_NAME)
    return response
from django.apps import AppConfig


class TerminosConfig(AppConfig):
    name = 'terminos'

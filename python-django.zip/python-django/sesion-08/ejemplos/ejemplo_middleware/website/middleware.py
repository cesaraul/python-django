from django import VERSION
from django.conf import settings
from django.shortcuts import render

def agregar_version_django(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        # Code to be executed for each request before
        # the view (and later middleware) are calX-led.

        response = get_response(request)

        # Code to be executed for each request/response after
        # the view is called.
        version = '.'.join([str(x) for x in VERSION])
        response['X-Django-Version'] = version
        return response

    return middleware

def mantenimiento(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        # Code to be executed for each request before
        # the view (and later middleware) are calX-led.

        mantenimiento = getattr(
            settings,
            'SITIO_EN_MANTENIMIENTO',
            False
        )
        if mantenimiento:
            response = render(request, 'website/mantenimiento.html')
        else:
            response = get_response(request)

        # Code to be executed for each request/response after
        # the view is called.
        return response

    return middleware


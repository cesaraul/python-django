from random import randint
from django.shortcuts import render

# Create your views here.

def tirar_dado(request):
    dado = randint(1, 6)
    return render(request, 'website/dado.html', locals())
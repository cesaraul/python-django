# Despliegue en producción

## ¿Qué es WSGI?

* Es una forma de conectar un framework web de Python
  con un ser servidor web.
* Implica que el servidor este escrito en Python ó este
  enlazado con un intérprete de Python.
    
## Servidores

* Apache incluye los módulos mod_wsgi y mod_wsgi_py3
* Nginx ó IIS pueden trabajar en modo proxy ó en modo
  fastcgi.
* uwsgi es un servidor escrito en C pero que se enlaza 
  con intérprete de Python
* gunicorn, paste, waitress son servidor escritos en puro
  Python.
  
## Instalar Apache y mod_wsgi_py3

```
$ sudo apt install apache2 libapache2-mod-wsgi-py3
```
## Crear carpetas 

```
$sudo mkdir -p /var/vhosts/ejemplo-despliegue.pe/code
$sudo mkdir -p /var/vhosts/ejemplo-despliegue.pe/logs
```
## Crear archivo de configuración del virtualhost

Crear el archivo `/etc/apache2/sites-available/ejemplo-despliegue.pe.conf`
con el siguiente contenido:

```
<VirtualHost *:80>
	ServerName ejemplo-despliegue.pe
	ServerAdmin webmaster@ejemplo-despliegue.pe
	DocumentRoot /var/vhosts/ejemplo-despliegue.pe/code

	<Directory /var/vhosts/ejemplo-despliegue.pe/code>
	    Options -Indexes +FollowSymLinks +MultiViews
            AllowOverride All
            Require all granted
        </Directory>

        WSGIScriptAlias / /var/vhosts/ejemplo-despliegue.pe/code/ejemplo_despliegue/wsgi.py

        <Directory /var/vhosts/ejemplo-despliegue.pe/code/ejemplo_despliegue>
            <Files wsgi.py>
                Require all granted
            </Files>
        </Directory>

        Alias /media/ /var/vhosts/ejemplo-despliegue.pe/code/media/
        Alias /static/ /var/vhosts/ejemplo-despliegue.pe/code/static/

       <Directory /var/vhosts/ejemplo-despliegue.pe/code/media/>
           Require all granted
       </Directory>

       <Directory /var/vhosts/ejemplo-despliegue.pe/code/static/>
           Require all granted
       </Directory>

	ErrorLog /var/vhosts/ejemplo-despliegue.pe/logs/error.log
	CustomLog /var/vhosts/ejemplo-despliegue.pe/logs/access.log combined
</VirtualHost>
```
## Activar el host virtual

```
$ ln -s /etc/apache2/sites-available/ejemplo-despliegue.pe.conf /etc/apache2/sites-enabled/
```

## Agregar el dominio a ALLOWED_HOSTS en el settings

```
ALLOWED_HOSTS = [
    'ejemplo-despliegue.py'
]
```

## Reiniciar Apache

```
sudo service apache2 restart
```

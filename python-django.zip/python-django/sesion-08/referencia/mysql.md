# MySQL

## Instalación

```
$ sudo apt install mysql-server mysql-client libmysqlclient-dev
$ sudo secure_mysql_installation
```

## Crear base de datos y usuario

```
$ sudo mysql
mysql> CREATE DATABASE mydatabase CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
mysql> GRANT ALL PRIVILEGES ON mydatabase.* TO myuser@localhost IDENTIFIED BY 'mypassword123';
mysql> FLUSH PRIVILEGES;
```
## Driver para Django

```
$ sudo apt install build-essential python3-dev libssl-dev
```
## Instalar dependencia

Teniando activado un entorno virtual ejecutan:

```
$ pip install mysqlclient
```

## Configuración en Django

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', 
        'NAME': 'nombre_de_base',
        'USER': 'usuario',
        'PASSWORD': 'password',
        'HOST': 'localhost',   # Or an IP Address that your DB is hosted on
        'PORT': '3306',
    }
}

## Conectarse desde la terminal

```
$ mysql -u myuser -p mydatabase
```
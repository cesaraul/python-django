# Trabajando con archivos estáticos en Django

## Configuración

En settings.py:

```python
#STATIC_URL = '/static/'
STATIC_URL = 'https://assets.midominio.com/'
STATIC_ROOT = os.path.join(BASE_DIR, 'static')

MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
```
## Recolectar archivos estáticos desde las distintas "apps"

```
$ python manage.py collectstatic
```

## Referenciando en las plantillas

```
#mi_plantilla.html

{% load static %}

<link rel="stylesheet" type="text/css" href="{% static 'ejemplos/estilos.css' %}">
```
"""proyecto73 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from website.views import (
    cualquier_nombre,
    formulario_area_triangulo,
    formulario_comentario,
    area_triangulo_restful,
    username_available

)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('area-triangulo/', formulario_area_triangulo),
    path('dejar-comentario/', formulario_comentario),
    path('api/area-triangulo', area_triangulo_restful),
    path('api/check-username-availability', username_available),
    path('', cualquier_nombre)
]

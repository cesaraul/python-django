from django.contrib.auth.models import User

def check_username_availability(username):
    qs = User.objects.filter(username=username)
    return not qs.exists()
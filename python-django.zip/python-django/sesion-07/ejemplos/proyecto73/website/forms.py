from django import forms
from django.core.exceptions import ValidationError

class AreaTrianguloForm(forms.Form):

    base = forms.FloatField(
        label='Base del triángulo'
    )
    
    altura = forms.FloatField(
        label='Altura del triángulo'
    )
    
    
class ComentarioForm(forms.Form):

    nombre = forms.CharField(
        label='Nombre',
        max_length=128,
        required=True
    )
    
    correo = forms.EmailField(
        label='Correo'
    )
    
    comentario = forms.CharField(
        label='Comentario',
        max_length=4096,
        widget=forms.Textarea(attrs={'rows': 5, 'cols': 40}) 
    )
    
    def clean_correo(self):
        #import pdb
        correo = self.cleaned_data['correo']
        correo = correo.strip().lower()
        #pdb.set_trace()
        try:
            dominio = correo.split('@')[1]
        except IndexError:
            dominio = None
        if dominio in ['hotmail.com', 'gmail.com', 'outlook.com']:
            raise ValidationError("El dominio del correo no está permitido")
        return correo

class UsernameAvailableForm(forms.Form):
    
    username = forms.CharField(
        label='Username',
        max_length=32,
        required=True
    )

    def clean_username(self):
        return self.cleaned_data['username'].strip().lower()
import json
from collections import OrderedDict
from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .forms import (
    AreaTrianguloForm,
    ComentarioForm,
    UsernameAvailableForm
)
from .utils import check_username_availability

# Create your views here.

def cualquier_nombre(request):
    return HttpResponse("<h1>Hola mundo</h1>")
    
def formulario_area_triangulo(request):
    area = None
    if request.method == 'POST':
        form = AreaTrianguloForm(request.POST)
        if form.is_valid():
            area = (form.cleaned_data['base'] * form.cleaned_data['altura'])/2
    else:
        form = AreaTrianguloForm()
    #contexto = {
    #    'form': form,
    #    'area': area
    #}
    return render(request, 'website/formulario_area_triangulo.html', locals())
    
def formulario_comentario(request):
    formulario_ok = False
    if request.method == 'POST':
        form = ComentarioForm(request.POST)
        if form.is_valid():
            formulario_ok = True
    else:    
        form = ComentarioForm()
    return render(request, 'website/formulario_comentario.html', locals())

@csrf_exempt
def area_triangulo_restful(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
        except:
            doc = OrderedDict()
            doc['estado'] = 'error'
            doc['errores'] = ["El payload debe estar en formato JSON"]            
            resp = HttpResponse(json.dumps(doc, indent=4))
            resp.status_code = 400
            return resp
        form = AreaTrianguloForm(data)
        if form.is_valid():
            area = (form.cleaned_data['base'] * form.cleaned_data['altura'])/2
            doc = OrderedDict()
            doc['estado'] = 'ok'
            doc['area'] = area
            return HttpResponse(json.dumps(doc, indent=4))
        else:
            doc['estado'] = 'error'
            doc['errores'] = form.errors
            resp = HttpResponse(json.dumps(doc, indent=4))
            resp.status_code = 400
            return resp
    else:
        doc = OrderedDict()
        doc['estado'] = 'error'
        doc['mensaje'] = "Método no soportado"
        resp = HttpResponse(json.dumps(doc, indent=4))
        resp.status_code = 405
        return resp

@csrf_exempt
def username_available(request):

    if not request.method == 'POST':
        doc = OrderedDict()
        doc['status'] = 'error'
        doc['messege'] = 'Method not allowed'
        resp = HttpResponse(json.dumps(doc, indent=4))
        resp['Content-Type'] = 'application/json; charset=utf-8'
        resp.status_code = 405
        return resp

    try:
        data = json.loads(request.body)
    except:
        doc = OrderedDict()
        doc['status'] = 'error'
        doc['messege'] = 'Payload must be valid JSON'
        resp = HttpResponse(json.dumps(doc, indent=4))
        resp['Content-Type'] = 'application/json; charset=utf-8'
        resp.status_code = 400
        return resp

    if type(data) is not dict:
        doc = OrderedDict()
        doc['status'] = 'error'
        doc['messege'] = 'Payload must be valid JSON object'
        resp = HttpResponse(json.dumps(doc, indent=4))
        resp['Content-Type'] = 'application/json; charset=utf-8'
        resp.status_code = 400
        return resp

    form = UsernameAvailableForm(data)
    if not form.is_valid():
        doc = OrderedDict()
        doc['status'] = 'error'
        doc['message'] = 'Bad request'
        doc['errors'] = form.errors
        resp = HttpResponse(json.dumps(doc, indent=4))
        resp['Content-Type'] = 'application/json; charset=utf-8'
        resp.status_code = 400
        return resp

    username = form.cleaned_data['username']
    available = check_username_availability(username)

    doc = OrderedDict()
    doc['status'] = 'ok'

    if available:
        doc['message'] = 'Username is available'        
    else:
        doc['message'] = 'Username is not available'

    doc['available'] = available

    resp = HttpResponse(json.dumps(doc, indent=4))
    resp['Content-Type'] = 'application/json; charset=utf-8'
    return resp
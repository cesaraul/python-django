from django import forms

class AritmeticaForm(forms.Form):

    OPERACION_CHOICES = (
        ('+', 'Adición'),
        ('-', 'Substracción'),
        ('*', 'Multiplicación'),
        ('/', 'División')
    )

    operando1 = forms.FloatField(
        label='Operando 1',
        required=True
    )
    
    operando2 = forms.FloatField(
        label='Operando 2',
        required=True
    )
    
    operacion = forms.ChoiceField(
        label='Operación',
        choices=OPERACION_CHOICES,
        required=True
    )
    
    def calcular_resultado(self):
        operando1 = self.cleaned_data['operando1']
        operando2 = self.cleaned_data['operando2']
        operacion = self.cleaned_data['operacion']
        
        if operacion == '+':
            resultado = operando1 + operando2
        elif operacion == '-':
            resultado = operando1 - operando2
        elif operacion == '*':
            resultado = operando1 * operando2
        elif operacion == '/':
            resultado = operando1 / operando2
        
        return resultado

from django.shortcuts import render
from .forms import AritmeticaForm

# Create your views here.

def formulario1(request):
    if request.method == 'POST':
        form = AritmeticaForm(request.POST)
        if form.is_valid():
            resultado = form.calcular_resultado()
    else:
        form = AritmeticaForm()
    return render(request, 'ejemplos/formulario1.html', locals())

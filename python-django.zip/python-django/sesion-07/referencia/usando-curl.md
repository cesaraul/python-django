# Probando APIs con cURL

## Enviando JSON

```
curl -vv -X GET -H "Content-Type: application/json" -d '{"base": 100.0, "altura": 50}' http://localhost:8000/api/area-triangulo
```

## Alternativas

* [Postman](https://www.getpostman.com)

# Trabajar con Visual Studio Code

## PASO 1: Descargar el ejecutable para tu sistema operativo.

En el caso de Ubuntu es el archivo con extensión `.deb`

## PASO 2: Instalar el paquete

En Ubuntu el comando es:

```
sudo dpkg -i code_1.40.2-1574694120_amd64.deb
```

### PASO 3: Agregar icono (OPCIONAL)

En GNOME (entorno visual de Ubuntu) ir a os 9 puntitos ("Mostrar aplaciones")
escribe "code" o "visual studio code" y agregar a favoritos ó arrastrar el
ícono a la barra.

### PASO 4: Instalar extensión de Python

Ir al ícono de los "cubitos" (extensiones) y buscar "Python" por Microsoft
(que es la más popular y aparece primero) y presionar el botón "Install"
ó "Instalar" de botón verde.

### PASO 5: Agregar al folder al espacio de trabajo (workspace)

Ir al meno "File" y seleccionar la opción "Add folder to Workspace" y
escoger el folder con la raiz del proyecto de Django y presionar el botón "Add"

### PASO 6: Seleccionar intérprete de Python

Ir a el menú "View", a la primera opción "Command Palete" (Ctrl+Shift+P)
y escribir "Python" para seleccionar el comando: "Python: Select Interpreter"
y escoger el Python del virtualenv que esten usando.



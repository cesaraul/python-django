# Notas sobre módulos

## ¿Qué es un módulo?

Es un archivo .py ó una carpeta que contiene 
archivos .py

## ¿Qué contiene los módulos?

Variables, funciones, clases y otros módulos

## ¿Cómo se importa un módulo?

```
import nombre_modulo
```

## ¿Cómo se importa un objeto específico desde un módulo?

```
from nombre_modulo import nombre_objeto
```

## ¿Cómo se cambia de nombre al objeto importado?

```
import nombre_objeto as nuevo_nombre
```

## ¿Cómo simplificar la ruta de importación?

Creando archivos __init__.py a nivel de los módulos que son
carpetas e importando otros símbolos ahí.

## ¿Cómo hacer importaciones relativas de módulos?

Con la sintaxis . (para la carpeta en donde se encuentra el
archivo con la sentencia import) y .. (para la carpeta que
contiene al archivio en donde está al sentencia import.

## ¿Desde que carpetas se pueden importar módulos?

Desde todas aquellas listadas en el $PYTHON_PATH:

```
import sys
print(sys.path)
```

## ¿Cómo agrego carpetas al $PYTHON_PATH?

```
import sys
sys.path.append('/home/python/')
sys.path.insert(1, '/home/python/utilitarios')
```

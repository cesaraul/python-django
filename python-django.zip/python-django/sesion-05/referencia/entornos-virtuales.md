# Trabajando con entornos virtuales en Python

## Instalando pre-requisitos (Ubuntu)

```
sudo apt install python3-venv
```

## Crear un entorno virtual

```
python -m venv nombre_entorno
```
 

## Activar un entorno virtual

```
source nombre_entorno/bin/activate
```

## Desactivar un entorno virtual

```
deactivate
```

## Instalar paquetes con pip

```
python -m pip install nombre_paquete
```

## Instalar una determinada versión de un paquete

python -m pip install nombre_paquete==numero_version

Ej.

```
python -m pip install Django=2.0
```

## Listar paquetes instalados en el entorno virtual

```
pip list --format=columns
```

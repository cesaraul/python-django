# Trabajando con el servidor web Apache

## Instalación

```
sudo apt install apache2
```

## Iniciar el servicio

```
sudo service apache2 start
```

## Comprobar servicio

```
sudo service apache2 status
```

Se puede ir con el navegador a:

http://localhost/

Con el comando `cURL` se puede ejecutar:

```
curl -vv http://localhost:80/
```

## Publicar contenido

Se tiene que copiar archivos a la ruta siguiente:

```
/var/www/html
```

ó subcarpetas a partir de ese nivel.

## Activar CGI

sudo ln -s /etc/apache2/mods-available/cgi.load /etc/apache2/mods-enabled/

## Reiniciar servicio

sudo service apache2 restart

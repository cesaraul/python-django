from functools import reduce

print(reduce(lambda a, b: a + b, (filter(lambda x: x % 2 == 0, (map(lambda x: x**2, range(1, 10 + 1))))), 0))

print([x**2 for x in range(1, 10 + 1)])
print([x**2 for x in range(1, 10 + 1) if x ** 2 % 2 == 0])
print(sum([x**2 for x in range(1, 10 + 1) if x ** 2 % 2 == 0]))


"""
Encontrar una cuenta de usuario de Twitter de 4 letras que no exista.

Instalar request:

python -m venv entorno
source entorno/bin/activate
python -m pip install requests
"""

import requests

while True:
    username = ''.join(random.sample(string.ascii_lowercase, 4))
    url = 'https://twitter.com/{username}'.format(username=username)
    resp = requests.get(url)
    if resp.status_code == 404:
        print(username)
        break

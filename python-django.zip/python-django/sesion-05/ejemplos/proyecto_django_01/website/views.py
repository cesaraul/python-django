import json
from collections import OrderedDict
from django.http import HttpResponse

# Create your views here.

def holamundo(request):
    return HttpResponse("<h1>Hola mundo</h1>")
    
def hola_con_nombre(request, nombre):
    return HttpResponse(f"<h1>Hola {nombre}</h1>")
    
def hola_con_nombre_en_json(request, nombre):
    doc = OrderedDict()
    doc['nombre'] = nombre
    doc['mensaje'] = f'¡Hola {nombre}!'
    resp = HttpResponse(json.dumps(doc, indent=4))
    resp['Content-Type'] = 'application/json; charset="utf8"';
    return resp
    

# Comandos de Django

## Iniciar un proyecto

```
django-admin.py startproject <nombre del proyecto>
```

## Correr migraciones

Las migraciones son scritps en Python que al ejecutarse
crean, modifican ó eliminan la estructura de las tablas
a nivel de la base de datos relacional.

```
python manage.py migrate
```

## Crear el super usuario

```
python manage.py createsuperuser
```

## Correr servidor web


```
python manage.py runserver
```

Si quiere cambiar de puerto ó IPs, se puede indicar la IP ó puerto 
en donde escuchar:

```
python manage.py runserver 0.0.0.0:8000
```

## Agrega una app

Una "app" es un módulo del proyecto de Django.

```
python manage.py startapp <nombre de la app>
```

## Agregar app a la configuración

Editar el archivo `settings.py` y agregar el módulo
de la app a la lista `INSTALLED_APPS`:

```python
# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'website'
]
```

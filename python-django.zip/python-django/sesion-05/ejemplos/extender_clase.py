class Padre(object):

    def __init__(self, **args, **kwargs):
        print("Yo soy el padre")

class Hijo(Padre):

    def __init__(self, **args, **kwargs):
        super().__init__()
        print("Yo soy el hijo")
        
if __name__ == '__main__':
    padre = Padre(**args, **kwargs)
    hijo = Hijo()

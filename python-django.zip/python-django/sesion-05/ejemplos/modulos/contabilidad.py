IGV = 0.18

def calcular_igv(monto):
    return monto * IGV

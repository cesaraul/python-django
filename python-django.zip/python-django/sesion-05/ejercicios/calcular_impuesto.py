IMPUESTO = 0.18

class CalculadorImpuesto(object):

    def __init__(self, porcentaje=IMPUESTO):
        self.porcentaje = porcentaje
        
    def __call__(self, monto):
        return monto * self.porcentaje
        
if __name__ == '__main__':

    calculadora_impuesto_20 = CalculadorImpuesto(porcentaje=0.20)
    calculadora_impuesto_10 = CalculadorImpuesto(porcentaje=0.10)
    
    calculadora_impuesto_10.porcentaje = 0.30
    
    print(calculadora_impuesto_20(10000))
    print(calculadora_impuesto_10(5000))

class Liquidacion(object):

    def __init__(self, sueldo, anios):
        self.sueldo = sueldo
        self.anios = anios
    
    def calcular_monto(self):
        return self.sueldo * self.anios

class LiquidacionConIncentivo(Liquidacion):

    def calcular_monto(self):
        return super().calcular_monto() * 1.20
        
if __name__ == '__main__':

    lq = Liquidacion(10, 1000)
    lq2 = LiquidacionConIncentivo(10, 1000)
    print(lq.calcular_monto())
    print(lq2.calcular_monto())

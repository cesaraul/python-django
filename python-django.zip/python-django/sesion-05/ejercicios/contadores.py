"""
Clear una clase Contador:

c = Contador() # cuenta en cero
c.inc()
c.inc()
c.inc()
print(c.obtener_valor()) # 3

"""

class Contador(object):

    def __init__(self):
        self.resetear()
        
    def resetear(self):
        self.valor = 0
    
    def inc(self):
        self.valor += 1
        
    def obtener_valor(self):
        return self.valor


class Contador2(Contador):
    
    def __init__(self, valor_inicial=0):
        self.valor_inicial = valor_inicial
        super().__init__()
        
    def resetear(self):
        self.valor = self.valor_inicial
 
class Contador3(Contador2):

    def __init__(self, valor_inicial=0, incremento=1):
        self.incremento = incremento
        super().__init__(valor_inicial)
    
    def inc(self):
        self.valor += self.incremento

 
if __name__ == '__main__':

    c1 = Contador()
    c1.inc()
    c1.inc()
    c1.inc()
    print(c1.obtener_valor())
    
    c2 = Contador2(1000)
    c2.inc()
    c2.inc()
    c2.inc()
    print(c2.obtener_valor())
    c2.resetear()
    print(c2.obtener_valor())
    
    c3 = Contador3(1000000, 10000)
    c3.inc()
    c3.inc()
    c3.inc()
    print(c3.obtener_valor())

"""
Crear una clase ValidadorPassword que
reciba los sigiuentes parámetros por nombre

min_digitos: número mínimo de caracteres numéricos
min_mayusculas: número mínimo de letras mayúsculas
min_minusculas: número mínimo de letras minúsculas
min_simbolos: número mínimo de caracteres de símbolos
min_longitud: longitud mínima de toda la contraseña

Y además considere los siguientes valores por omisión:

MIN_DIGITOS = 1
MIN_MAYUSCULAS = 1
MIN_MINUSCULAS = 1
MIN_SIMBOLOS = 1
MIN_LONGITUD = 8

Ejemplo:

validador1 = ValidadorPassword(min_longitud=12)
print(validador1.validar("P4ssw0rd$$$$"))

params = {
    'min_longitud': 16,
    'min_simbolos': 2,
    'min_digitos': 4
}

validador2 = ValidadorPassword(**params)

print(validador1.validar("k$j32123x_12k4s4"))
"""

class ValidadorPassword(object):

    MIN_LONGITUD = 8
    
    def __init__(self, **kwargs):
        self.min_longitud = kwargs.get(
            'min_longitud',
            self.MIN_LONGITUD
        )
        
    def calcula r_longitud(self):
        return len(self.valor)
        
    def verificar_longitud(self):
        return self.calcular_longitud() >= self.min_longitud
    
    def __call__(self, password):
        return self.verificar_longitud() and \
            self.verificar_mayusculas() and \
            self.verificar_minusculas() and \
            self.verificar_digitos() and \
            self.verificar_simbolos()

# Comandos de Django

## Crear un entorno virtual

```
virtualenv --python=/usr/bin/python3 mi_entorno
```

## Activar el entorno virtual

```
source mi_entorno/bin/activate
```

### Instalar Django 

```
pip install Django
```

## Iniciar un proyecto

```
django-admin.py startproject <nombre del proyecto>
```

## Correr migraciones

Las migraciones son scritps en Python que al ejecutarse
crean, modifican ó eliminan la estructura de las tablas
a nivel de la base de datos relacional.

```
python manage.py migrate
```

## Crear el super usuario

```
python manage.py createsuperuser
```

## Correr servidor web


```
python manage.py runserver
```

Si quiere cambiar de puerto ó IPs, se puede indicar la IP ó puerto 
en donde escuchar:

```
python manage.py runserver 0.0.0.0:8000
```

## Agrega una app

Una "app" es un módulo del proyecto de Django.

```
python manage.py startapp <nombre de la app>
```

## Agregar app a la configuración

Editar el archivo `settings.py` y agregar el módulo
de la app a la lista `INSTALLED_APPS`:

```python
# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'website'
]
```

## Crear un modelo

Se edita el archivo `models.py` de alguna de las apps 
creando una ó más clases que herenden de `django.db.models.Model`.

## Crear las migraciones

Se corre el comando:

```
python manage.py makemigrations
```

## Ejecutar las migraciones pendientes

```
python manage.py migrate
```

## Ingresar a la shell de la base de datos

Se ejecuta el comando siguiente:

```
python manage.py dbshell
```

En el caso de usar SQLite3 en Ubuntu tenemos que tener
instalado el paquete `sqlite3`:

```
sudo apt install sqlite3
```

Ejemplo de sesión con sqlite:

```
SQLite version 3.22.0 2018-01-22 18:45:57
Enter ".help" for usage hints.
sqlite> .tables
auth_group                  django_admin_log          
auth_group_permissions      django_content_type       
auth_permission             django_migrations         
auth_user                   django_session            
auth_user_groups            folders_folder            
auth_user_user_permissions
sqlite> .schema folders_folder
CREATE TABLE IF NOT EXISTS "folders_folder" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(128) NOT NULL, "slug" varchar(128) NOT NULL, "description" text NULL, "created_at" datetime NOT NULL, "updated_at" datetime NOT NULL, "parent_id" integer NULL REFERENCES "folders_folder" ("id") DEFERRABLE INITIALLY DEFERRED);
CREATE UNIQUE INDEX "folders_folder_slug_parent_id_ea68cb8e_uniq" ON "folders_folder" ("slug", "parent_id");
CREATE INDEX "folders_folder_slug_5d408788" ON "folders_folder" ("slug");
CREATE INDEX "folders_folder_parent_id_470f7767" ON "folders_folder" ("parent_id");
```

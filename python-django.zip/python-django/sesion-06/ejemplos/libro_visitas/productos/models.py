from django.db import models
from django.utils.translation import gettext as _

# Create your models here.

class Producto(models.Model):

    nombre = models.CharField(
        verbose_name=_('Nombre'),
        max_length=128
    )
    
    precio_unitario = models.DecimalField(
        verbose_name=_('Precio unitario'),
        max_digits=8,
        decimal_places=2,
        default=0.0
    )
    
    class Meta:
        verbose_name = _('producto')
        verbose_name_plural = _('productos')
        ordering = ('nombre', )
        
    def __str__(self):
        return self.nombre

from django.shortcuts import render
from .models import Producto

# Create your views here.

def listado_productos(request):
    productos = Producto.objects.all()
    contexto = {}
    contexto['productos'] = productos
    return render(request, 'productos/listado.html', contexto)

from django.contrib import admin
from .models import (
    Motivo,
    Visita
)

# Register your models here.

class MotivoAdmin(admin.ModelAdmin):

    list_display = (
        'id', 'nombre'
    )
    
admin.site.register(Motivo, MotivoAdmin)    


class VisitaAdmin(admin.ModelAdmin):

    list_display = (
        'id', 'nombre', 'correo',
        'longitud_comentarios', 'creado_en'
    )
    
    search_fields = (
        'nombre', 'correo', 'comentarios'
    )
    
    readonly_fields = ('id', 'creado_en')
    
    list_filter = ('motivo', )
    
    def longitud_comentarios(self, instance):
        return len(instance.comentarios)

admin.site.register(Visita, VisitaAdmin)

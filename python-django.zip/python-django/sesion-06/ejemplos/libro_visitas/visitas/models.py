from django.db import models
from django.utils.translation import gettext as _

# Create your models here.

class Motivo(models.Model):

    nombre = models.CharField(
        verbose_name=_('Nombre'),
        max_length=128,
        unique=True
    )
    
    creado_en = models.DateTimeField(
        verbose_name=_('Fecha y hora de creación'),
        auto_now_add=True
    )
    
    class Meta:
        verbose_name = _('motivos')
        verbose_name_plural = _('motivos')
        
    def __str__(self):
        return self.nombre


class Visita(models.Model):

    motivo = models.ForeignKey(Motivo,
        verbose_name=_('Motivo'),
        on_delete=models.PROTECT,
        related_name='visitas',
        null=True,
        blank=True
    )

    nombre = models.CharField(
        verbose_name=_('Nombre'),
        max_length=128
    )
    
    correo = models.EmailField(
        verbose_name=_('Correo'),
        null=True,
        blank=True
    )
    
    comentarios = models.TextField(
        verbose_name=_('Comentarios'),
        null=True,
        blank=True
    )
    
    creado_en = models.DateTimeField(
        verbose_name=_('Fecha y hora de creación'),
        auto_now_add=True
    )
    
    class Meta:
        verbose_name = _('visita')
        verbose_name_plural = _('visitas')
        
    def __str__(self):
        return self.nombre

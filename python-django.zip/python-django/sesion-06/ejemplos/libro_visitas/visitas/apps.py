from django.apps import AppConfig


class VisitasConfig(AppConfig):
    name = 'visitas'

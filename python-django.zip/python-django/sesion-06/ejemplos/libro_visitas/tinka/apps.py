from django.apps import AppConfig


class TinkaConfig(AppConfig):
    name = 'tinka'

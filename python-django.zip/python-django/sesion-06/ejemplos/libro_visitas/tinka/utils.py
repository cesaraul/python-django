# utils.py

from random import sample

BOLILLA_INICIAL = 1
BOLILLA_FINAL = 45
NUM_BOLILLAS = 6
LISTA_BOLILLAS = range(BOLILLA_INICIAL, BOLILLA_FINAL+1)

def crear_n_jugadas_tinka(num_jugadas):
    jugadas = []
    while len(jugadas) < num_jugadas:
        j = "-".join(["%02d" % b for b in sorted(sample(LISTA_BOLILLAS, NUM_BOLILLAS))])
        if j not in jugadas:
            jugadas.append(j)
    return jugadas

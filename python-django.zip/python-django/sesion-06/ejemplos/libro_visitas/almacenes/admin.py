from django.contrib import admin
from .models import (
    Almacen,
    Stock
)

# Register your models here.

class AlmacenAdmin(admin.ModelAdmin):

    list_display = ('pk', 'nombre', 'direccion')
    readonly_fields = ('id', )
    
admin.site.register(Almacen, AlmacenAdmin)

class StockAdmin(admin.ModelAdmin):

    list_display = ('pk', 'almacen', 'producto', 'cantidad')
    readonly_fields = ('pk', )
    
    list_filter = ('almacen', 'producto')
    
admin.site.register(Stock, StockAdmin)

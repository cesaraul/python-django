from django.apps import AppConfig


class AlmacenesConfig(AppConfig):
    name = 'almacenes'

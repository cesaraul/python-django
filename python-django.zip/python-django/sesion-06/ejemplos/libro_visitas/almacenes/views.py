from django.shortcuts import (
    render,
    get_object_or_404
)
from .models import Almacen

# Create your views here.

def almacenes(request):
    almacenes = Almacen.objects.all()
    return render(request, 'almacenes/listado.html', locals())
    
def stock(request, pk):
    almacen = get_object_or_404(Almacen, pk=pk)
    return render(request, 'almacenes/stock.html', locals())

from django.db import models
from django.utils.translation import gettext as _
from productos.models import Producto

# Create your models here.

class Almacen(models.Model):

    nombre = models.CharField(
        verbose_name=_('Nombre'),
        max_length=128
    )
    
    direccion = models.TextField(
        verbose_name=_('Dirección')
    )
    
    class Meta:
        verbose_name = _('almacen')
        verbose_name_plural = _('almacenes')
        
    def __str__(self):
        return self.nombre
     
        
class Stock(models.Model):
 
    almacen = models.ForeignKey(Almacen,
        verbose_name=_('Almacén'),
        on_delete=models.PROTECT,
        related_name='registros_de_stock'
    )
    
    producto = models.ForeignKey(Producto,
        verbose_name=_('Producto'),
        on_delete=models.PROTECT,
        related_name='registros_de_stock'
    )
    
    cantidad = models.PositiveIntegerField(
        verbose_name=_('Cantidad'),
        default=0
    )
    
    class Meta:
        verbose_name = _('registro de stock')
        verbose_name_plural = _('registros de stock')
        
    def __str__(self):
        return "Registro de stock #{pk}".format(pk=self.pk)

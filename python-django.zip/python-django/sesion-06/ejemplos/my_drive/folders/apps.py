from django.apps import AppConfig


class FoldersConfig(AppConfig):
    name = 'folders'

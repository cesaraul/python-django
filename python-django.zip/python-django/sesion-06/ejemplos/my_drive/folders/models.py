from django.db import models
from django.utils.translation import gettext as _

# Create your models here.

class Folder(models.Model):

    name = models.CharField(
        verbose_name=_('Nombre'),
        max_length=128
    )
    
    slug = models.SlugField(
        verbose_name=_('Nombre'),
        max_length=128,
        unique=False
    )
    
    description = models.TextField(
        verbose_name=_('Descripción'),
        null=True,
        blank=True
    )
    
    parent = models.ForeignKey('self',
        verbose_name=_('Folder padre'),
        on_delete=models.PROTECT,
        null=True,
        blank=True
    )
    
    created_at = models.DateTimeField(
        verbose_name=_('Fecha y hora de creación'),
        auto_now_add=True   
    )
    
    updated_at = models.DateTimeField(
        verbose_name=_('Fecha y hora de actualización'),
        auto_now=True   
    )
    
    class Meta:
        verbose_name = _('folder')
        verbose_name = _('folders')
        unique_together = [
            ('slug', 'parent')
        ]
